<?php

namespace Laminas\Db\Sql;

class Having extends Predicate\Predicate
{
}
