<?php
require dirname(__FILE__) . '/../src/Upload/Autoloader.php';
\Upload\Autoloader::register();
