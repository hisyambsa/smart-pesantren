<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

/*
  |--------------------------------------------------------------------------
  | App details
  |
  | 
  |--------------------------------------------------------------------------
 */

/******************************************************************************
 * Onesignal Production Account details 
 * Email: ******@******.com
 * App Name: Production App Name
 * 
 * Updated On: 2017/10/07
 *******************************************************************************/
$config['app_id'] = '539e467a-dd56-43fb-a40a-c3eead933bae'; // localhost
$config['safari_web_id'] = 'web.onesignal.auto.44737891-769a-4856-a052-0f3c94719003'; // localhost

$config['authorization'] = 'YjlkYTg3OWYtZGNjOC00MTc4LWJjOGMtNWUwMjRkOTJjY2Nl';

$config['debug_mode'] = false;

/******************************************************************************
 * End
 *******************************************************************************/


/******************************************************************************
 * Testing account details
 * Email: ****@****.com
 * App Name: Onesignal - testing app
 * 
 * Updated On: 2018/01/25
 *******************************************************************************/
// $config['app_id'] = '*************************************';
// $config['authorization'] = '*********************************************';

// $config['debug_mode'] = true;

/******************************************************************************
 * End
 *******************************************************************************/

/* End of file onesignal.php */
/* Location: ./application/config/onesignal.php */
