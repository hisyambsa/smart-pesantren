<?php

namespace Laminas\Db\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
